LaTeX source package - AI-Based Smart Electricity Consumption Prediction and Anomaly Detection
================================================================================================

Contents
--------
paper/main.tex         Full LaTeX source (10-page journal-style article)
paper/refs.bib         Bibliography (natbib/unsrtnat)
paper/cover.html       HTML cover page (A4, print-to-PDF ready)
paper/final_paper.pdf  Compiled paper (November 2026, DIU CSE authors)
figures/               All publication figures referenced by main.tex

How to compile
--------------
The .tex file references figures via ../figures/, so compile from inside paper/:

  cd paper
  tectonic main.tex          (recommended, ~30 s, auto-downloads packages)
  # or: pdflatex main && bibtex main && pdflatex main && pdflatex main

Requirements: a TeX distribution with natbib, booktabs, tikz, hyperref
(tectonic handles all of these automatically).

Authors: MD Tamim Hossen, Md Emon Sarkar, MD. Montasir Hasan,
         Sidratul Muntaha, Shorov Shahriar
Supervisor: Paritosh Chandra Ray, Lecturer, Dept. of CSE, DIU
